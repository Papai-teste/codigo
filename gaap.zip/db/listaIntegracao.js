// lista das ações cadastradas tabela acao
module.exports = {
  ACESSO_GOV:"ACESSO_GOV",
  API_CONFIA:"API_CONFIA",
  CPF_LIGHT:"CPF_LIGHT",
  SENATRAN:"SENATRAN",
  PDC:"PDC",
  API_CONTAS:"API_CONTAS"
  }
  