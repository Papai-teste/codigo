// lista das ações cadastradas tabela acao
module.exports = {
  CRED_EMP:"CRED_EMP",
  SOL_CONS:"SOL_CONS",
  CAD_API:"CAD_API",
  CON_CONS:"CON_CONS",
  APR_CONS:"APR_CONS",
  REV_CONS:"REV_CONS",
  LGI_GAAP:"LGI_GAAP",
  // consulta mockada
  CON_COND:"CON_COND",
  // consulta dados pessoais
  CON_PESS:"CON_PESS",
  // consultas senatran
  SEN_COND_CPF:"SEN_COND_CPF",
  SEN_VEIC_CPF_PL:"SEN_VEIC_CPF_PL",
  SEN_INFRA_CPF:"SEN_INFRA_CPF"
  }
  