'use strict';

module.exports = function (app) {
  /*
    #swagger.path = '/v1/consentimento/aprovar/{idConsentimento}'
    #swagger.parameters['idConsentimento'] = { 
        in: 'path',
        description: "ID do consentimento a ser aprovado",
        required: true
    }

    #swagger.security = [{
        "bearerAuth": []
    }]

    #swagger.responses[204] = { description: 'Consentimento aprovado.' }
    #swagger.responses[400] = { description: 'Bad Request' }
    #swagger.responses[401] = { description: 'Unauthorized' }
    #swagger.responses[404] = { description: 'Registro não encontrado na base' }
    #swagger.responses[422] = { description: 'Unprocessable Entity' }
    #swagger.responses[429] = { description: 'Too Many Requests' }
    #swagger.responses[500] = { description: 'Internal Server Error' }
    #swagger.responses[502] = { description: 'Erro em alguma das APIs consumidas pelo GaaP' }
  */
};
